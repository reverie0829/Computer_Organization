#include <bits/stdc++.h>
using namespace std;

vector<int> Hex_To_Bi(string s)
{
    vector<int> v;
    for (auto i = 2; i <10; ++i)
    {
        switch (s.at(i))
        {
        case '0':
            v.push_back(0);v.push_back(0);v.push_back(0);v.push_back(0);break;
        case '1':
            v.push_back(0);v.push_back(0);v.push_back(0);v.push_back(1);break;
        case '2':
            v.push_back(0);v.push_back(0);v.push_back(1);v.push_back(0);break;
        case '3':
            v.push_back(0);v.push_back(0);v.push_back(1);v.push_back(1);break;
        case '4':
            v.push_back(0);v.push_back(1);v.push_back(0);v.push_back(0);break;
        case '5':
            v.push_back(0);v.push_back(1);v.push_back(0);v.push_back(1);break;
        case '6':
            v.push_back(0);v.push_back(1);v.push_back(1);v.push_back(0);break;
        case '7':
            v.push_back(0);v.push_back(1);v.push_back(1);v.push_back(1);break;
        case '8':
            v.push_back(1);v.push_back(0);v.push_back(0);v.push_back(0);break;
        case '9':
            v.push_back(1);v.push_back(0);v.push_back(0);v.push_back(1);break;
        case 'a':
            v.push_back(1);v.push_back(0);v.push_back(1);v.push_back(0);break;
        case 'b':
            v.push_back(1);v.push_back(0);v.push_back(1);v.push_back(1);break;
        case 'c':
            v.push_back(1);v.push_back(1);v.push_back(0);v.push_back(0);break;
        case 'd':
            v.push_back(1);v.push_back(1);v.push_back(0);v.push_back(1);break;
        case 'e':
            v.push_back(1);v.push_back(1);v.push_back(1);v.push_back(0);break;
        case 'f':
            v.push_back(1);v.push_back(1);v.push_back(1);v.push_back(1);break;
        }
    }
	reverse(v.begin(),v.end());
	return v;
}

int power(int a, int n)
{
	int x = 1;
	while (n)
	{
		if (n & 1)
			x *= a;
		a *= a;
		n >>= 1;
	}
	return x;
}

int Bi_To_Dec(const vector<int> &v)
{
	int decimal = 0;
	for (int i = 0; i < v.size(); ++i)
	{
		if (v.at(i) == 1)
			decimal += power(2, i);
	}
	return decimal;
}

class CacheEntry
{
public:
	int counter;
	int timeLabel;
	vector<int> tagBits;

	CacheEntry(int t); //constructor

	void writeTag(const vector<int> &tag)
	{
		tagBits = tag;
	}
};
CacheEntry::CacheEntry(int t) // : counter(-1), timeLabel(-1)
{
	counter = -1;
	timeLabel = -1;
	tagBits.assign(t, -1);
}

class CacheSet
{
public:
	int tagLength;
	int entryNum;
	vector<CacheEntry *> entries;
	int Hit_Entry_Id;

	CacheSet(int t, int n); //constructor

	bool findSameTag(const vector<int> &tag)
	{
		Hit_Entry_Id = -1;
		for (int i = 0; i < entryNum; ++i)
		{
			if (entries[i]->tagBits == tag)
			{
				Hit_Entry_Id = i;
				return true;
			}
		}
		return false;
	}

	int getEmptyId()
	{
		for (int i = 0; i < entries.size(); ++i)
		{
			if (entries[i]->tagBits[0] == -1)
				return i;
		}
		return -1;
	}

	void sort_label_id()
	{
		sort(entries.begin(), entries.end(), [](const auto &a, const auto &b) { return a->timeLabel < b->timeLabel; });
	}

	int getMostLabelId()
	{
		return entries.size() - 1;
	}
};
CacheSet::CacheSet(int t, int n) // : tagLength(t), entryNum(n)
{
	tagLength = t;
	entryNum = n;
	for (int i = 0; i < entryNum; ++i)
	{
		CacheEntry *temp = new CacheEntry(tagLength);
		entries.push_back(temp);
	}
}

class Cache
{
public:
	int CacheSize;	  //KB
	int BlockSize;	  //B
	int AssociateNum; //0 direct-mapped, 1 four-way set associative, 2 fully associative
	int PolicyNum;	  // FIFO=0 , LRU=1, Your Policy=2

	int blockNum;
	int setNum;
	int entryPerSet;
	int indexLength;
	int tagLength;
	vector<CacheSet *> sets;
	int timeCnt;
	vector<int> victimTag;

	Cache(int c, int b, int a, int p); //constructor

	bool Cache_Write_FIFO(vector<int> addr)
	{
		//read the address
		vector<int> tag(tagLength, 0), index;
		int setId; //index in decimal

		for (int i = 0; i < tagLength; ++i)
		{
			tag[i] = addr[32 - tagLength + i];
		}

		if (indexLength != 0)
		{
			index.assign(indexLength, 0);
			for (int i = 0; i < indexLength; ++i)
			{
				index[i] = addr[32 - tagLength - indexLength + i];
			}
			setId = Bi_To_Dec(index);
		}
		else
		{
			setId = 0;
		}

		//hit or not
		bool Find_Or_Not = sets[setId]->findSameTag(tag);

		if (!Find_Or_Not)
		{ //if not hit
			int emptyId = sets[setId]->getEmptyId();
			if (emptyId != -1)
			{ //if has empty entry
				sets[setId]->entries[emptyId]->writeTag(tag);
				sets[setId]->entries[emptyId]->timeLabel = timeCnt++;
				return false;
			}
			else
			{ //if no empty entry
				sets[setId]->sort_label_id();
				int victimEntryId = 0;									  //find the victim entry , 0 is least because sorted already
				victimTag = sets[setId]->entries[victimEntryId]->tagBits; //get victim's tag
				sets[setId]->entries[victimEntryId]->writeTag(tag);
				sets[setId]->entries[victimEntryId]->timeLabel = timeCnt++;
				return true;
			}
		}
		else
		{
			return false;
		}
	}

	bool Cache_Write_LRU(vector<int> addr)
	{
		//read the address
		vector<int> tag(tagLength, 0), index;
		int setId; //index in decimal

		for (int i = 0; i < tagLength; ++i)
		{
			tag[i] = addr[32 - tagLength + i];
		}

		if (indexLength != 0)
		{
			index.assign(indexLength, 0);
			for (int i = 0; i < indexLength; ++i)
			{
				index[i] = addr[32 - tagLength - indexLength + i];
			}
			setId = Bi_To_Dec(index);
		}
		else
		{
			setId = 0;
		}

		//hit or not
		bool Find_Or_Not = sets[setId]->findSameTag(tag);

		if (!Find_Or_Not)
		{ //if not hit
			int emptyId = sets[setId]->getEmptyId();
			if (emptyId != -1)
			{ //if has empty entry
				sets[setId]->entries[emptyId]->writeTag(tag);
				sets[setId]->entries[emptyId]->timeLabel = timeCnt++;
				return false;
			}
			else
			{ //if no empty entry
				sets[setId]->sort_label_id();
				int victimEntryId = 0;									  //find the victim entry , 0 is least because sorted already
				victimTag = sets[setId]->entries[victimEntryId]->tagBits; //get victim's tag
				sets[setId]->entries[victimEntryId]->writeTag(tag);
				sets[setId]->entries[victimEntryId]->timeLabel = timeCnt++;
				return true;
			}
		}
		else
		{ //if hit
			int idx = sets[setId]->Hit_Entry_Id;
			sets[setId]->entries[idx]->timeLabel = timeCnt++;
			return false;
		}
	}

	bool Cache_Write_Myself(vector<int> addr)
	{
		//read the address
		vector<int> tag(tagLength, 0), index;
		int setId; //index in decimal

		for (int i = 0; i < tagLength; ++i)
		{
			tag[i] = addr[32 - tagLength + i];
		}

		if (indexLength != 0)
		{
			index.assign(indexLength, 0);
			for (int i = 0; i < indexLength; ++i)
			{
				index[i] = addr[32 - tagLength - indexLength + i];
			}
			setId = Bi_To_Dec(index);
		}
		else
		{
			setId = 0;
		}

		//hit or not
		bool findOrNot = sets.at(setId)->findSameTag(tag);

		if (!findOrNot)
		{ //if not hit
			int emptyId = sets.at(setId)->getEmptyId();
			if (emptyId != -1)
			{ //if has empty entry
				sets[setId]->entries[emptyId]->writeTag(tag);
				sets[setId]->entries[emptyId]->timeLabel = timeCnt++;
				return false;
			}
			else
			{ //if no empty entry
				sets[setId]->sort_label_id();
				int victimEntryId = sets[setId]->getMostLabelId();		  //find the victim entry
				victimTag = sets[setId]->entries[victimEntryId]->tagBits; //get victim's tag
				sets[setId]->entries[victimEntryId]->writeTag(tag);
				sets[setId]->entries[victimEntryId]->timeLabel = timeCnt++;
				return true;
			}
		}
		else
		{ //if hit
			int idx = sets[setId]->Hit_Entry_Id;
			sets[setId]->entries[idx]->timeLabel = timeCnt++;
			return false;
		}
	}
};
Cache::Cache(int c = 1024, int b = 16, int a = 0, int p = 0)
{
	CacheSize = c;
	BlockSize = b;
	AssociateNum = a;
	PolicyNum = p;
	//calculate bits
	blockNum = CacheSize * 1024 / BlockSize;
	if (AssociateNum == 0)
	{ //direct-mapped
		setNum = blockNum;
		entryPerSet = 1;
	}
	else if (AssociateNum == 1)
	{ //4-way associative
		setNum = blockNum / 4;
		entryPerSet = 4;
	}
	else
	{ //fully associative
		setNum = 1;
		entryPerSet = blockNum;
	}

	int offset = log(BlockSize) / log(2);
	indexLength = log(setNum) / log(2);
	tagLength = 32 - offset - indexLength;

	//initialize CacheSet
	for (int i = 0; i < setNum; ++i)
	{
		CacheSet *temp = new CacheSet(tagLength, entryPerSet);
		sets.push_back(temp);
	}

	//intialize timeCnt & victimTag
	timeCnt = 0;
	victimTag.assign(tagLength, -1);
}

int main(int argc, char *argv[])
{
	int CacheSize, BlockSize, AssociateNum, PolicyNum;

	ifstream inFile(argv[1], ios::in);
	if (!inFile)
	{
		cerr << "your reading file is wrong" << endl;
		exit(1);
	}

	ofstream outFile(argv[2], ios::out);
	if (!outFile)
	{
		cerr << "your writting file is wrong" << endl;
		exit(1);
	}

	inFile >> CacheSize >> BlockSize >> AssociateNum >> PolicyNum;

	Cache *myCache = new Cache(CacheSize, BlockSize, AssociateNum, PolicyNum);

	string addr;
	while (inFile >> addr)
	{
		vector<int> v;
		v = Hex_To_Bi(addr);

		bool result;
		if (PolicyNum == 0)
		{ //FIFO
			result = myCache->Cache_Write_FIFO(v);
		}
		else if (PolicyNum == 2)
		{ //my policy
			result = myCache->Cache_Write_Myself(v);
		}
		else
		{ //LRU
			result = myCache->Cache_Write_LRU(v);
		}

		if (!result)
			outFile << -1 << endl;
		else
		{
			int outputTag = Bi_To_Dec(myCache->victimTag);
			outFile << outputTag << endl;
			;
		}
	}

	delete myCache;
	return 0;
}